#include <iostream>
#include<vector>
#include<math.h>
#include<algorithm>
#include<unordered_map>
#include <string> 
#include<math.h>

using namespace std;
int main() {
    vector<vector<int>> arr;
    int size = 10;
    arr.resize(size);
    for (int i = 0; i < 10; i++)
        arr[i].resize(10);
     arr[9][9]=10;
     cout << arr[9][9];
    return 0;

}
   

   






